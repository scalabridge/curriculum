/*
package doodle.examples

import doodle.core._
import doodle.syntax._

object ExampleName extends Drawable {
  def draw: Image = ???
}
*/
